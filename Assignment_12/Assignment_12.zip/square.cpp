/*
 Student Name
 
*/

#include <iostream>
#include <cstdlib>

using namespace std;

int main()
{
    int side_length = 9

    cout << "The square of " << side_length << " is " << side_length*side_length << endl;
    cout << "& the cube of " << side_length << " is " side_length*side_length << end;
    
    system("PAUSE");
    return EXIT_SUCCESS; 
    /*note that in order to use return EXIT_SUCCESS; you need to include the header file #include <cstdlib>
      If you decide to instead use return 0; then you do not need to include the header file #include <cstdlib>
    */
}

/*
Paste the output here

*/
